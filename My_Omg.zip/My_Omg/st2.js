// var active = document.getElementById('#choice-1');
// var inactive = document.getElementById('#choice-2');


// function check_actiact () {
// 	if(active)
// {
// 	var Protein_needed = weight * 1.5;
// 	console.log("Protein_needed");

// }else
// {
// 	var Protein_needed = weight * 1;
// 	console.log("Protein_needed");
// }
// 	// body...
// }



$("button").keypress(function(){

	console.log("Key Pressed");
});